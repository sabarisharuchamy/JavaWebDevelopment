DROP TABLE farmer
